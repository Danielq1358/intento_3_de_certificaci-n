# Donación de Peluches

Este proyecto es una página web para compartir peluches. Las personas pueden crear una cuenta, publicar donaciones y adoptar peluches de otras personas. La aplicación está hecha con Flask y guarda sus datos en MySQL.

## Funciones principales

- Crear una cuenta, iniciar sesión y cerrar sesión.
- Publicar peluches y buscar por su descripción.
- Ver los detalles de cada peluche.
- Editar o borrar las donaciones propias.
- Adoptar peluches que todavía estén disponibles.
- Mostrar errores cuando los datos de un formulario no son válidos.

## Carpetas y archivos principales

```text
.
├── flask_app/
│   ├── config/                 # Configuración de la aplicación y conexión con MySQL
│   ├── controllers/            # Rutas para usuarios y peluches
│   ├── models/                 # Consultas y validaciones
│   ├── static/css/             # Estilos de la página
│   ├── templates/              # Páginas HTML
│   └── __init__.py             # Crea la aplicación y registra las rutas
├── resources/db/
│   └── esquema_peluches.sql    # Tablas necesarias para MySQL
├── .env.example                # Ejemplo de configuración local
├── .gitignore                 # Archivos locales que no se deben compartir
├── Pipfile
├── README.md
├── requirements.txt
└── server.py                  # Inicia el servidor web
```

Los controladores reciben las solicitudes de la página, los modelos trabajan con la base de datos y las plantillas muestran el contenido. `server.py` inicia la aplicación.

## Preparar el proyecto en Windows

Abre PowerShell en la carpeta del proyecto y crea un entorno de Python:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

Si PowerShell impide activar el entorno, puedes ejecutar los comandos de Python usando directamente `.\.venv\Scripts\python.exe`.

## Preparar MySQL

Inicia MySQL y crea las tablas ejecutando el esquema desde la carpeta del proyecto:

```powershell
cmd /c "mysql -u root -p < resources\db\esquema_peluches.sql"
```

También puedes abrir `resources/db/esquema_peluches.sql` en MySQL Workbench y ejecutarlo allí.

## Configurar la aplicación

1. Crea tu archivo privado `.env` a partir del ejemplo:

   ```powershell
   Copy-Item .env.example .env
   ```

2. Abre `.env` y reemplaza los valores de ejemplo por los datos de tu instalación de MySQL.
3. Cambia `SECRET_KEY` por una clave privada. Puedes generar una desde PowerShell con:

   ```powershell
   python -c "import secrets; print(secrets.token_hex(32))"
   ```

El archivo `.env` contiene información privada, como la clave de la aplicación y la contraseña de MySQL. No lo compartas ni lo subas al repositorio. `.gitignore` está configurado para ignorarlo.

## Iniciar la aplicación

Con el entorno activado y `.env` configurado, inicia el servidor:

```powershell
python server.py
```

Abre <http://127.0.0.1:5000/> en el navegador. Para detener el servidor, presiona `Ctrl+C` en PowerShell.

## Ejecutar las pruebas

El proyecto todavía no incluye pruebas automatizadas. Si más adelante agregas
pruebas dentro de la carpeta `tests`, puedes ejecutarlas con:

```powershell
python -m unittest discover -s tests
```
