import pymysql
from flask import current_app
from pymysql.cursors import DictCursor


class MySQLConnection:
    def __init__(self):
        self.connection = pymysql.connect(
            host=current_app.config["MYSQL_HOST"],
            port=current_app.config["MYSQL_PORT"],
            user=current_app.config["MYSQL_USER"],
            password=current_app.config["MYSQL_PASSWORD"],
            database=current_app.config["MYSQL_DATABASE"],
            charset="utf8mb4",
            cursorclass=DictCursor,
            autocommit=True,
        )

    def query_db(self, query, data=None):
        with self.connection.cursor() as cursor:
            cursor.execute(query, data or {})
            if cursor.description:
                return cursor.fetchall()
            if query.lstrip().lower().startswith("insert"):
                return cursor.lastrowid
            return cursor.rowcount


def connect_to_mysql():
    return MySQLConnection()
