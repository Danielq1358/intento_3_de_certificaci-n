from flask import Blueprint, redirect, render_template, request, session, url_for
from pymysql.err import IntegrityError

from flask_app.models.usuario import Usuario

# Este blueprint agrupa las páginas para registrar e iniciar sesión.
usuarios = Blueprint("usuarios", __name__)


@usuarios.route("/inicio", methods=["GET"])
def index():
    if session.get("usuario_id"):
        return redirect(url_for("peluches.index"))
    return render_template("autenticar_inicio/index.html")


@usuarios.route("/registrar", methods=["POST"])
def registrar():
    # Convertimos y validamos los datos antes de crear la cuenta.
    usuario = Usuario.desde_formulario(request.form)
    errores = usuario.validar_registro()
    if not errores and Usuario.buscar_por_email(usuario.email):
        errores.append("Este correo ya se encuentra registrado.")
    if errores:
        return render_template(
            "autenticar_inicio/index.html",
            errores_registro=errores,
            valores=request.form,
        ), 400

    try:
        # Si la base de datos detecta un correo repetido, mostramos un error claro.
        usuario_id = usuario.guardar()
    except IntegrityError as error:
        if error.args and error.args[0] == 1062:
            return render_template(
                "autenticar_inicio/index.html",
                errores_registro=["Este correo ya se encuentra registrado."],
                valores=request.form,
            ), 400
        raise

    # Guardamos quién inició sesión para usar su cuenta en las demás páginas.
    session.clear()
    session["usuario_id"] = usuario_id
    session["usuario_nombre"] = usuario.nombre
    return redirect(url_for("peluches.index"))


@usuarios.route("/iniciar-sesion", methods=["POST"])
def iniciar_sesion():
    # Buscamos la cuenta y comprobamos su contraseña.
    usuario = Usuario.autenticar(
        request.form.get("email_login", ""),
        request.form.get("password_login", ""),
    )
    if usuario is None:
        return render_template(
            "autenticar_inicio/index.html",
            error_inicio="Correo o contraseña incorrectos.",
        ), 400

    # Dejamos los datos básicos de la persona en la sesión.
    session.clear()
    session["usuario_id"] = usuario.id
    session["usuario_nombre"] = usuario.nombre
    return redirect(url_for("peluches.index"))


@usuarios.route("/cerrar-sesion")
def cerrar_sesion():
    # Borramos la sesión para cerrar el acceso.
    session.clear()
    return redirect(url_for("usuarios.index"))
