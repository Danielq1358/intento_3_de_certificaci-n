import re

from werkzeug.security import check_password_hash, generate_password_hash

from flask_app.config.mysqlconnection import connect_to_mysql


_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


class Usuario:
    def __init__(
        self,
        nombre="",
        apellido="",
        email="",
        id=None,
        password_hash="",
        _contrasena="",
        _confirmacion="",
    ):
        self.nombre = nombre
        self.apellido = apellido
        self.email = email
        self.id = id
        self.password_hash = password_hash
        self._contrasena = _contrasena
        self._confirmacion = _confirmacion

    @classmethod
    def desde_formulario(cls, datos):
        # Limpiamos los espacios y dejamos el correo en minúsculas.
        return cls(
            nombre=(datos.get("nombre") or "").strip(),
            apellido=(datos.get("apellido") or "").strip(),
            email=(datos.get("email") or "").strip().lower(),
            _contrasena=datos.get("contrasena") or "",
            _confirmacion=datos.get("confirmar_contrasena") or "",
        )

    def validar_registro(self) -> list[str]:
        errores = []

        # Revisamos cada dato y guardamos los mensajes para mostrarlos en pantalla.
        if not 2 <= len(self.nombre) <= 80:
            errores.append("El nombre debe tener entre 2 y 80 caracteres.")
        if not 2 <= len(self.apellido) <= 80:
            errores.append("El apellido debe tener entre 2 y 80 caracteres.")
        if len(self.email) > 190 or not _EMAIL_RE.fullmatch(self.email):
            errores.append("Ingresa un correo electrónico válido.")
        if len(self._contrasena) < 8:
            errores.append("La contraseña debe tener al menos 8 caracteres.")
        elif len(self._contrasena) > 128:
            errores.append("La contraseña no puede superar los 128 caracteres.")
        if self._contrasena != self._confirmacion:
            errores.append("La confirmación de la contraseña no coincide.")

        return errores

    @classmethod
    def buscar_por_email(cls, email):
        conexion = connect_to_mysql()
        try:
            # Buscamos la cuenta por correo; la consulta usa parámetros.
            usuarios = conexion.query_db(
                "SELECT id, nombre, apellido, email, password_hash "
                "FROM usuarios WHERE email = %(email)s LIMIT 1",
                {"email": (email or "").strip().lower()},
            )
            if not usuarios:
                return None
            return cls(**usuarios[0])
        finally:
            conexion.connection.close()

    def guardar(self) -> int:
        conexion = connect_to_mysql()
        try:
            # Guardamos un hash, nunca la contraseña escrita por la persona.
            return conexion.query_db(
                """
                INSERT INTO usuarios (nombre, apellido, email, password_hash)
                VALUES (%(nombre)s, %(apellido)s, %(email)s, %(password_hash)s)
                """,
                {
                    "nombre": self.nombre,
                    "apellido": self.apellido,
                    "email": self.email,
                    "password_hash": generate_password_hash(self._contrasena),
                },
            )
        finally:
            conexion.connection.close()

    @classmethod
    def autenticar(cls, email, contrasena):
        usuario = cls.buscar_por_email(email)
        # Solo iniciamos sesión si la contraseña coincide con el hash guardado.
        if usuario and check_password_hash(usuario.password_hash, contrasena):
            return usuario
        return None
