import pymysql
from flask import Flask, redirect, render_template, request, session, url_for

from flask_app.config.config import Config


def crear_app(test_config=None):
    app = Flask(__name__)
    app.config.from_object(Config)
    if test_config:
        app.config.update(test_config)
    if not app.config.get("SECRET_KEY"):
        raise RuntimeError(
            "Configura la variable de entorno SECRET_KEY antes de iniciar la aplicación."
        )

    from flask_app.controllers import peluches, usuarios

    app.register_blueprint(peluches)
    app.register_blueprint(usuarios)

    @app.route("/")
    def inicio():
        if session.get("usuario_id") is not None:
            return redirect(url_for("peluches.index"))
        return redirect(url_for("usuarios.index"))

    @app.errorhandler(404)
    def pagina_no_encontrada(error):
        # Si la dirección no existe, volvemos al inicio de sesión.
        if request.endpoint is None:
            return redirect(url_for("usuarios.index"))
        # Las páginas válidas que no encuentran un dato siguen mostrando 404.
        return error.get_response()

    @app.errorhandler(pymysql.err.OperationalError)
    def error_base_datos(error):
        if error.args and error.args[0] == 1049:
            mensaje = (
                "No se encuentra la base de datos. Ejecuta el esquema "
                "resources/db/esquema_peluches.sql en MySQL y vuelve a intentarlo."
            )
        else:
            mensaje = (
                "No se pudo conectar con MySQL. Revisa que el servidor esté "
                "activo y que los datos de conexión estén configurados correctamente."
            )
        return render_template("errores/base_datos.html", mensaje=mensaje), 503

    return app
